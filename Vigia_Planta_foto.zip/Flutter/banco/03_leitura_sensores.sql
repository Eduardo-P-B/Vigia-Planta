-- Leituras dos sensores (luz, umidade e temperatura)
-- Rode só se a tabela ainda não existir (não apaga nada se já existir).
USE cl205441;

CREATE TABLE IF NOT EXISTS leitura_sensores (
  id          INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  luz_solar   DECIMAL(10,2),
  umidade     DECIMAL(10,2),
  temperatura DECIMAL(10,2)
);

-- Exemplo de leituras para teste (opcional):
-- INSERT INTO leitura_sensores (luz_solar, umidade, temperatura) VALUES (82.50, 47.00, 26.40);
-- INSERT INTO leitura_sensores (luz_solar, umidade, temperatura) VALUES (90.00, 52.30, 27.10);
