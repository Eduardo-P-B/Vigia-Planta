-- Plantas de exemplo (opcional: no app também dá para adicionar pelo botão +)
-- Troque o 1 pelo seu id:  SELECT id, nome FROM usuarios;
USE cl205441;

INSERT INTO plantas (usuario_id, nome, foto, umidade, luz_solar, temperatura, descricao, ultima_rega, proxima_rega) VALUES
(1, 'Podo Carpus (Externo)', 'assets/images/podocarpo.jpg',  0.20, 0.95, 27.5, 'Precisa de atenção urgente! Rega necessária.', CURDATE() - INTERVAL 5 DAY, CURDATE()),
(1, 'Podo Carpus (Interno)', 'assets/images/podocarpo2.jpg', 0.45, 0.40, 23.0, 'Nível de água baixo, regar em breve.',        CURDATE() - INTERVAL 3 DAY, CURDATE() + INTERVAL 1 DAY),
(1, 'Croton',                'assets/images/croton.jpg',     0.60, 1.00, 26.0, 'Planta saudável, continue assim!',             CURDATE() - INTERVAL 2 DAY, CURDATE() + INTERVAL 2 DAY),
(1, 'Rosa',                  'assets/images/rosa.jpg',       0.85, 0.67, 25.0, 'Linda e saudável!',                            CURDATE() - INTERVAL 1 DAY, CURDATE() + INTERVAL 3 DAY),
(1, 'Costela de Adão',       'assets/images/costela.jpg',    0.70, 0.80, 24.5, 'Planta exuberante!',                           CURDATE() - INTERVAL 2 DAY, CURDATE() + INTERVAL 2 DAY),
(1, 'Cacto',                 'assets/images/cacto.jpg',      0.75, 0.95, 29.0, 'Resistente e forte!',                          CURDATE() - INTERVAL 4 DAY, CURDATE() + INTERVAL 5 DAY),
(1, 'Lírio da Paz',          'assets/images/lirio.jpg',      1.00, 0.80, 22.5, 'Paz e harmonia no ambiente.',                  CURDATE(),                  CURDATE() + INTERVAL 3 DAY),
(1, 'Suculenta',             'assets/images/suculenta.jpg',  1.00, 0.95, 28.0, 'Pequena mas cheia de vida!',                   CURDATE(),                  CURDATE() + INTERVAL 4 DAY);
