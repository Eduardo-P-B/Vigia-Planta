-- =====================================================
-- VIGIA PLANTA - banco simplificado (2 tabelas)
-- Servidor 143.106.241.4 | usuário cl205441
-- Se o seu schema tiver outro nome, troque na linha USE.
-- =====================================================
USE cl205441;

-- Limpa versões anteriores (apaga os dados antigos!)
DROP VIEW  IF EXISTS vw_plantas;
DROP TABLE IF EXISTS historico_regas;
DROP TABLE IF EXISTS plantas;
DROP TABLE IF EXISTS usuarios;

CREATE TABLE usuarios (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  nome             VARCHAR(100) NOT NULL,
  email            VARCHAR(100) NOT NULL UNIQUE,
  senha            VARCHAR(255) NOT NULL,      -- guardada criptografada pela API
  telefone         VARCHAR(20),
  aceita_lembretes TINYINT(1) DEFAULT 0
);

-- umidade e luz_solar: de 0.00 a 1.00 (igual ao app)
CREATE TABLE plantas (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id   INT NOT NULL,
  nome         VARCHAR(100) NOT NULL,
  foto         VARCHAR(255),                   -- caminho do asset ou URL
  umidade      DECIMAL(3,2) DEFAULT 0.50,
  luz_solar    DECIMAL(3,2) DEFAULT 0.50,
  temperatura  DECIMAL(4,1),                   -- °C
  descricao    VARCHAR(255),
  ultima_rega  DATE,
  proxima_rega DATE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Leituras dos sensores (não é apagada acima, para não perder suas leituras)
CREATE TABLE IF NOT EXISTS leitura_sensores (
  id          INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  luz_solar   DECIMAL(10,2),
  umidade     DECIMAL(10,2),
  temperatura DECIMAL(10,2)
);
