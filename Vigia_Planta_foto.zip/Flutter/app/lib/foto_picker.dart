// Escolhe a implementação certa conforme a plataforma (navegador ou outras).
export 'foto_escolhida.dart';
export 'foto_picker_stub.dart'
    if (dart.library.js_interop) 'foto_picker_web.dart';
