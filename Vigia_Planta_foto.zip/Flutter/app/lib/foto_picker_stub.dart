import 'foto_escolhida.dart';

/// Versão para celular/desktop: o seletor sem plugin só existe no navegador.
const bool fotoSuportada = false;

Future<FotoEscolhida?> escolherFoto() async => null;
