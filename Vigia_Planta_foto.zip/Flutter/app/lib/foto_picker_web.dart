import 'dart:async';
import 'dart:js_interop';
import 'package:web/web.dart' as web;
import 'foto_escolhida.dart';

/// No navegador (Chrome) dá para abrir a janela de arquivos do computador.
const bool fotoSuportada = true;

Future<FotoEscolhida?> escolherFoto() {
  final completer = Completer<FotoEscolhida?>();
  final input = web.document.createElement('input') as web.HTMLInputElement;
  input.type = 'file';
  input.accept = 'image/*';

  input.addEventListener(
    'change',
    ((web.Event _) {
      _lerArquivo(input, completer);
    }).toJS,
  );
  input.addEventListener(
    'cancel',
    ((web.Event _) {
      if (!completer.isCompleted) completer.complete(null);
    }).toJS,
  );

  input.click();
  return completer.future;
}

Future<void> _lerArquivo(
  web.HTMLInputElement input,
  Completer<FotoEscolhida?> completer,
) async {
  try {
    final files = input.files;
    if (files == null || files.length == 0) {
      if (!completer.isCompleted) completer.complete(null);
      return;
    }
    final file = files.item(0)!;
    final buffer = await file.arrayBuffer().toDart;
    final bytes = buffer.toDart.asUint8List();
    if (!completer.isCompleted) {
      completer.complete(FotoEscolhida(bytes, file.name));
    }
  } catch (_) {
    if (!completer.isCompleted) completer.complete(null);
  }
}
