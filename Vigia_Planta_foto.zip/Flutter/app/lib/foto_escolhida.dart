import 'dart:typed_data';

/// Foto escolhida pelo usuário (bytes + nome do arquivo).
class FotoEscolhida {
  final Uint8List bytes;
  final String nome;
  const FotoEscolhida(this.bytes, this.nome);
}
