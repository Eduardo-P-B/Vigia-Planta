# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\aluno\\AppData\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\aluno\\Downloads\\Vigia-Planta-main\\Vigia-Planta-main\\Documentos Geral\\Flutter\\app" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\aluno\\AppData\\flutter"
  "PROJECT_DIR=C:\\Users\\aluno\\Downloads\\Vigia-Planta-main\\Vigia-Planta-main\\Documentos Geral\\Flutter\\app"
  "FLUTTER_ROOT=C:\\Users\\aluno\\AppData\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\aluno\\Downloads\\Vigia-Planta-main\\Vigia-Planta-main\\Documentos Geral\\Flutter\\app\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\aluno\\Downloads\\Vigia-Planta-main\\Vigia-Planta-main\\Documentos Geral\\Flutter\\app"
  "FLUTTER_TARGET=C:\\Users\\aluno\\Downloads\\Vigia-Planta-main\\Vigia-Planta-main\\Documentos Geral\\Flutter\\app\\lib\\2main.dart"
  "DART_DEFINES=RkxVVFRFUl9CVUlMRF9OQU1FPTEuMC4w,RkxVVFRFUl9CVUlMRF9OVU1CRVI9MQ==,RkxVVFRFUl9WRVJTSU9OPTMuNDcuNw==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049YWJhZjljNTIzNw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZGViMjg3NDgxZQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMy41"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\aluno\\Downloads\\Vigia-Planta-main\\Vigia-Planta-main\\Documentos Geral\\Flutter\\app\\.dart_tool\\package_config.json"
)
