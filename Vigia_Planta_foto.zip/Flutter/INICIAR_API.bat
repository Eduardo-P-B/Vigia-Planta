@echo off
cd /d "%~dp0api"
echo Liberando a porta 3333 (se estiver ocupada)...
powershell -NoProfile -Command "Get-NetTCPConnection -LocalPort 3333 -State Listen -ErrorAction SilentlyContinue | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
if not exist node_modules call npm install
echo.
echo Iniciando a API... (deixe esta janela aberta)
npm start
pause
