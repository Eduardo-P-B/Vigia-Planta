@echo off
cd /d "%~dp0app"
call flutter pub get
flutter run -t lib/2main.dart -d chrome
pause
