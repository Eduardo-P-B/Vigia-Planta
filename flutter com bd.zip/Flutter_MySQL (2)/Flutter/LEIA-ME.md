# Vigia Planta - Flutter + MySQL (servidor 143.106.241.4)

Estrutura:
- banco/  -> scripts SQL
- api/    -> API Node.js (liga o app ao MySQL)
- app/    -> projeto Flutter

Passo a passo:
1. Workbench: conecte em cl205441 (143.106.241.4:3306), abra banco/01_schema.sql e execute.
   (se o seu schema tiver outro nome, troque a linha "USE cl205441;")
2. api/.env: troque COLOQUE_SUA_SENHA_AQUI pela senha do MySQL.
3. cd api -> npm install -> npm start   (deve aparecer "Conectado ao MySQL")
4. cd app -> flutter pub get -> flutter run -t lib/2main.dart
5. Crie sua conta no app e adicione plantas pelo botão + (ou use banco/02_seed_plantas.sql trocando o 1 pelo seu id).
6. Faca login: as plantas vem do MySQL.

Celular real: em app/lib/api_service.dart preencha urlManual com http://IP_DO_PC:3000/api
Se nao conectar no MySQL: o servidor pode aceitar so a rede da escola/VPN.
