const path = require('path');
const mysql = require('mysql2/promise');

// Lê as configurações de conexão do arquivo .env (na raiz do projeto)
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'vigia_planta',
    dateStrings: true, // DATE volta como texto 'AAAA-MM-DD', sem problema de fuso horário
    waitForConnections: true,
    connectionLimit: 5
});

// Devolve as plantas no mesmo formato que o dados.json tinha,
// então as telas (renderer) continuam funcionando sem mudanças.
async function listarPlantas() {
    const [linhas] = await pool.query(`
        SELECT p.id,
               p.imagem,
               p.nome,
               p.nivel_umidade AS nivelUmidade,
               p.nivel_luz AS nivelLuz,
               COALESCE(p.localizacao, '') AS localizacao,
               e.chave AS especie,
               p.data_plantio AS data
        FROM planta p
        LEFT JOIN especie e ON e.id = p.especie_id
        ORDER BY p.id
    `);
    return linhas.map(linha => ({ ...linha }));
}

async function inserirPlanta(dados) {
    const [resultado] = await pool.query(
        `INSERT INTO planta
            (nome, especie_id, localizacao, data_plantio, imagem, nivel_umidade, nivel_luz)
         VALUES
            (?, (SELECT id FROM especie WHERE chave = ?), ?, ?, ?, ?, ?)`,
        [
            dados.nome,
            dados.especie || null,
            dados.localizacao || null,
            dados.data || null,
            dados.imagem || 'plantaPadrao.png',
            dados.nivelUmidade ?? 100,
            dados.nivelLuz ?? 100
        ]
    );
    return resultado.insertId;
}

// Retorna o nome da planta, ou null se o id não existir
async function buscarNomePlanta(id) {
    const [linhas] = await pool.query('SELECT nome FROM planta WHERE id = ?', [id]);
    return linhas.length > 0 ? linhas[0].nome : null;
}

async function removerPlanta(id) {
    await pool.query('DELETE FROM planta WHERE id = ?', [id]);
}

function fechar() {
    return pool.end();
}

module.exports = { listarPlantas, inserirPlanta, buscarNomePlanta, removerPlanta, fechar };
