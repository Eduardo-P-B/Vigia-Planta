const { app, BrowserWindow, ipcMain, Menu, Tray, dialog } = require('electron');
const path = require('path');
const banco = require('./database');
let janela;
let janelaModal;
let tray = null;

const criarJanela = () => {
    janela = new BrowserWindow({
        width: 1920,
        height: 1080,
        frame: false,
        fullscreen: true,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js')
        },
    });
    janela.loadFile('../renderer/home.html');
    // Abre o painel lateral do desenvolvedor
    janela.webContents.openDevTools();
};

// Mover a função para fora do app.whenReady()
const criarMenuPrincipal = (janelaDialog) => {
    const templateDoMenu = [
        {
            label: 'Ações do Sistema',
            submenu: [
                { label: 'Sair Imediatamente', role: 'quit', accelerator: 'CmdOrCtrl+Q' }
            ],
        },
    ];

    // 2. Transforma a receita em um Menu de verdade
    const menuReal = Menu.buildFromTemplate(templateDoMenu);

    // 3. Aplica o menu à nossa aplicação inteira!
    Menu.setApplicationMenu(menuReal);
};

// Avisa o usuário quando o MySQL não responde (servidor parado, senha errada etc.)
function mostrarErroBanco(acao, erro) {
    console.error(`Erro ao ${acao}:`, erro);
    dialog.showErrorBox(
        'Erro no banco de dados',
        `Não foi possível ${acao}.\n\n${erro.message}\n\nConfira se o MySQL está rodando e se os dados do arquivo .env estão corretos.`
    );
}

app.whenReady().then(() => {
    criarJanela();

    ipcMain.on('abrir-modal-cadastro', () => {
        janelaModal = new BrowserWindow({
            width: 800,
            height: 540,
            parent: janela,
            modal: true,
            frame: false,
            resizable: false,
            transparent: true,
            backgroundColor: '#00000000',
            webPreferences: {
                preload: path.join(__dirname, 'preload.js')
            },
        });
        janelaModal.loadFile('../renderer/cadastroPlanta.html')
    });

    ipcMain.on('fechar', () => {
        app.quit();
    });

    ipcMain.handle('pedir-plantas', async () => {
        try {
            return await banco.listarPlantas();
        } catch (erro) {
            mostrarErroBanco('carregar as plantas', erro);
            return [];
        }
    });

    ipcMain.on('fechar-modal-cadastro', () => {
        if (janelaModal) {
            janelaModal.close();
        }
    });

    ipcMain.handle('salvar', async (e, dados) => {
        try {
            await banco.inserirPlanta(dados);

            janela.webContents.send('atualizar-tela');

            return true;
        } catch (erro) {
            mostrarErroBanco('salvar a planta', erro);
            return false;
        }
    });

    // CHAME a função aqui!
    criarMenuPrincipal(janela);

    // O caminho da imagem que você baixou
    const iconeCaminho = path.join(__dirname, 'images/icone.png');

    // Cria o ícone no cantinho do relógio
    tray = new Tray(iconeCaminho);

    // Define a mensagem que aparece ao passar o mouse por cima
    tray.setToolTip('Vigia PLanta');

    const menuDoTray = Menu.buildFromTemplate([
        {
            label: 'Abrir Painel',
            click: () => {
                janela.show();
            }
        },
        { type: 'separator' },
        {
            label: 'Encerrar', click: () => {
                app.isQuitting = true;
                app.quit();
            }
        }
    ]);

    // Intercepte o fechamento da janela
    janela.on('close', (event) => {
        if (!app.isQuitting) {
            event.preventDefault();
            janela.hide();
        }
    });

    tray.setContextMenu(menuDoTray);
});

ipcMain.handle('deletar-planta', async (e, id) => {
    try {
        const nome = await banco.buscarNomePlanta(id);

        if (nome !== null) {
            // 1. Mostra o diálogo de confirmação
            // 2. Decide com base no índice do botão clicado
            const respostaDeletar = await dialog.showMessageBox({
                type: 'warning',
                title: 'Remover Planta',
                message: `Tem certeza que deseja excluir "${nome}"?`,
                buttons: ['Sim, remover', 'Cancelar'],
                defaultId: 1,
                cancelId: 1
            });

            if (respostaDeletar.response === 0) {
                await banco.removerPlanta(id);
            }
        }

        return await banco.listarPlantas();
    } catch (erro) {
        mostrarErroBanco('remover a planta', erro);
        return [];
    }
});

// Fecha a conexão com o MySQL quando o app realmente encerra
app.on('will-quit', () => {
    banco.fechar().catch(() => {});
});

ipcMain.on('sair-app', async () => {
    const respostaDeletar = await dialog.showMessageBox({
        type: 'warning',
        title: 'Fechar app',
        message: `Quer mesmo sair?`,
        buttons: ['Sim, sair','Deixar em Segundo Plano','Encerrar Sessão', 'cancelar'],
        defaultId: 3,
        cancelId: 3
    });
    if (respostaDeletar.response === 0) {
        app.isQuitting = true;
        app.quit(app.isQuitting);
    }
    if (respostaDeletar.response === 1) {
        app.quit();
    }
    if (respostaDeletar.response === 2) {
    }
});