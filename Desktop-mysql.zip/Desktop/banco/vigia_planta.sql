-- =====================================================================
--  VIGIA PLANTA - Banco de dados (MySQL 5.7+ / 8.x)
--
--  Como usar no MySQL Workbench:
--    1. Abra o Workbench e conecte na sua instância (ex.: "Local instance MySQL80").
--    2. File > Open SQL Script... e escolha este arquivo.
--    3. Execute tudo: botão do raio (Execute) ou Ctrl+Shift+Enter.
--    4. No painel SCHEMAS, clique em Refresh: o schema "vigia_planta" aparece lá.
--
--  Para gerar o diagrama EER: Database > Reverse Engineer... (Ctrl+R)
-- =====================================================================

SET NAMES utf8mb4;

-- Para recriar tudo do zero (APAGA todos os dados), tire o "--" da linha abaixo:
-- DROP DATABASE IF EXISTS vigia_planta;

CREATE DATABASE IF NOT EXISTS vigia_planta
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_unicode_ci;

USE vigia_planta;

-- ---------------------------------------------------------------------
--  Tabela especie: opções do campo "Espécie" do formulário de cadastro
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS especie (
  id    INT UNSIGNED NOT NULL AUTO_INCREMENT,
  chave VARCHAR(30)  NOT NULL COMMENT 'Valor da opção no formulário (ex.: croton)',
  nome  VARCHAR(60)  NOT NULL COMMENT 'Nome exibido (ex.: Croton)',
  PRIMARY KEY (id),
  UNIQUE KEY uq_especie_chave (chave)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
--  Tabela planta: as plantas cadastradas (antes ficavam no dados.json)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS planta (
  id            INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  nome          VARCHAR(100)     NOT NULL,
  especie_id    INT UNSIGNED     NULL,
  localizacao   VARCHAR(100)     NULL,
  data_plantio  DATE             NULL,
  imagem        VARCHAR(255)     NOT NULL DEFAULT 'plantaPadrao.png' COMMENT 'Nome do arquivo em src/renderer/images',
  nivel_umidade TINYINT UNSIGNED NOT NULL DEFAULT 100 COMMENT 'Nível de umidade (0 a 100)',
  nivel_luz     TINYINT UNSIGNED NOT NULL DEFAULT 100 COMMENT 'Nível de luz solar (0 a 100)',
  criado_em     TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  atualizado_em TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_planta_especie (especie_id),
  CONSTRAINT fk_planta_especie
    FOREIGN KEY (especie_id) REFERENCES especie (id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT ck_planta_umidade CHECK (nivel_umidade BETWEEN 0 AND 100),
  CONSTRAINT ck_planta_luz     CHECK (nivel_luz BETWEEN 0 AND 100)
) ENGINE = InnoDB;

-- ---------------------------------------------------------------------
--  Dados iniciais (rode só uma vez; vieram do dados.json)
--  Obs.: no dados.json antigo só a planta 10 tinha "especie"; nas demais a
--  espécie foi deduzida pelo nome/foto (ex.: podocarpo.jpg -> Podocarpo).
-- ---------------------------------------------------------------------
INSERT INTO especie (id, chave, nome) VALUES
  (1, 'podocarpo', 'Podocarpo'),
  (2, 'costela', 'Costela de Adão'),
  (3, 'croton', 'Croton'),
  (4, 'lirio', 'Lírio da Paz'),
  (5, 'cacto', 'Cacto'),
  (6, 'suculenta', 'Suculenta'),
  (7, 'rosa', 'Rosa');

INSERT INTO planta (id, nome, especie_id, localizacao, data_plantio, imagem, nivel_umidade, nivel_luz) VALUES
  (1, 'Podocarpus (Externo)', 1, 'Jardim da Frente', NULL, 'podocarpo.jpg', 20, 95),
  (2, 'Podocarpus (Interno)', 1, 'Sala de Estar', NULL, 'podocarpo2.jpg', 70, 40),
  (3, 'Croton', 3, 'Varanda Gourmet', NULL, 'croton.jpg', 60, 100),
  (4, 'Rosa', 7, 'Canteiro do Quintal', NULL, 'rosa.jpg', 85, 67),
  (5, 'Costela de Adão', 2, 'Escritório', NULL, 'costela.jpg', 70, 80),
  (6, 'Cacto', 5, 'Terraço', NULL, 'cacto.jpg', 75, 95),
  (7, 'Lírio da Paz', 4, 'Quarto Principal', NULL, 'lirio.jpg', 100, 80),
  (8, 'Suculenta', 6, 'Estante da Sala', NULL, 'suculenta.jpg', 100, 95),
  (9, 'Podocarpus construída', 1, 'Entrada da Casa', NULL, 'podocarpo.jpg', 100, 100),
  (10, 'Croton Criada', 3, 'Entrada da casa', '2026-06-05', 'plantaPadrao.png', 100, 100);

-- Conferência: deve listar as 10 plantas
SELECT p.id, p.nome, e.nome AS especie, p.localizacao, p.data_plantio, p.nivel_umidade, p.nivel_luz
FROM planta p
LEFT JOIN especie e ON e.id = p.especie_id
ORDER BY p.id;
