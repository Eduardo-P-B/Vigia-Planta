require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
});

// ---------- helpers ----------
// status calculado pela umidade (mesma regra das cores do app)
const STATUS_SQL = `CASE WHEN umidade < 0.30 THEN 'urgent'
                        WHEN umidade < 0.50 THEN 'warning'
                        ELSE 'normal' END`;

function textoPassado(data) {
  if (!data) return 'Nunca';
  const dias = Math.floor((Date.now() - new Date(data)) / 86400000);
  if (dias <= 0) return 'Hoje';
  return dias === 1 ? 'Há 1 dia' : `Há ${dias} dias`;
}

function textoFuturo(data) {
  if (!data) return '-';
  const dias = Math.ceil((new Date(data) - Date.now()) / 86400000);
  if (dias <= 0) return 'Hoje';
  if (dias === 1) return 'Amanhã';
  return `Em ${dias} dias`;
}

// Converte a linha do banco para o MESMO formato (chaves) que o app já usa
function formatarPlanta(p) {
  return {
    id: p.id,
    name: p.nome,
    image: p.foto || '',
    waterLevel: Number(p.umidade),
    sunLevel: Number(p.luz_solar),
    temperatura: p.temperatura === null ? null : Number(p.temperatura),
    status: p.status,
    descricao: p.descricao || '',
    ultimaRega: textoPassado(p.ultima_rega),
    proximaRega: textoFuturo(p.proxima_rega),
  };
}

// ---------- AUTH ----------
app.post('/api/cadastro', async (req, res) => {
  try {
    const { nome, email, senha, telefone, aceitaLembretes } = req.body;
    if (!nome || !email || !senha || !telefone)
      return res.status(400).json({ erro: 'Preencha todos os campos.' });
    if (senha.length < 6)
      return res.status(400).json({ erro: 'Senha deve ter pelo menos 6 caracteres.' });

    const [existe] = await pool.query('SELECT id FROM usuarios WHERE email = ?', [email]);
    if (existe.length) return res.status(409).json({ erro: 'E-mail já cadastrado.' });

    const hash = await bcrypt.hash(senha, 10);
    const [r] = await pool.query(
      'INSERT INTO usuarios (nome, email, senha, telefone, aceita_lembretes) VALUES (?,?,?,?,?)',
      [nome, email, hash, telefone, aceitaLembretes ? 1 : 0]
    );
    res.status(201).json({ id: r.insertId, nome, email });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { email, senha } = req.body;
    const [rows] = await pool.query('SELECT * FROM usuarios WHERE email = ?', [email]);
    if (!rows.length || !(await bcrypt.compare(senha, rows[0].senha)))
      return res.status(401).json({ erro: 'E-mail ou senha inválidos!' });
    const u = rows[0];
    res.json({ id: u.id, nome: u.nome, email: u.email });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// ---------- BUSCA DE USUÁRIOS ----------
app.get('/api/usuarios/busca', async (req, res) => {
  try {
    const { termo = '', tipo = 'nome' } = req.query;
    if (!termo) return res.json([]);
    const coluna = tipo === 'email' ? 'email' : 'nome'; // whitelist (evita SQL injection)
    const [rows] = await pool.query(
      `SELECT id, nome, email, telefone FROM usuarios WHERE ${coluna} LIKE ?`,
      [`%${termo}%`]
    );
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// ---------- PLANTAS ----------
app.get('/api/usuarios/:uid/plantas', async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT *, ${STATUS_SQL} AS status FROM plantas WHERE usuario_id = ? ORDER BY umidade ASC`,
      [req.params.uid]
    );
    res.json(rows.map(formatarPlanta));
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

app.post('/api/plantas', async (req, res) => {
  try {
    const { usuarioId, nome, foto, umidade, luzSolar, temperatura, descricao } = req.body;
    if (!usuarioId || !nome) return res.status(400).json({ erro: 'usuarioId e nome são obrigatórios.' });
    const [r] = await pool.query(
      `INSERT INTO plantas (usuario_id, nome, foto, umidade, luz_solar, temperatura, descricao, proxima_rega)
       VALUES (?,?,?,?,?,?,?, CURDATE() + INTERVAL 3 DAY)`,
      [usuarioId, nome, foto || null, umidade ?? 0.5, luzSolar ?? 0.5, temperatura ?? null, descricao || null]
    );
    const [rows] = await pool.query(`SELECT *, ${STATUS_SQL} AS status FROM plantas WHERE id = ?`, [r.insertId]);
    res.status(201).json(formatarPlanta(rows[0]));
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

app.put('/api/plantas/:id', async (req, res) => {
  try {
    const { nome, foto, umidade, luzSolar, temperatura, descricao } = req.body;
    await pool.query(
      `UPDATE plantas SET nome = COALESCE(?, nome), foto = COALESCE(?, foto),
         umidade = COALESCE(?, umidade), luz_solar = COALESCE(?, luz_solar),
         temperatura = COALESCE(?, temperatura), descricao = COALESCE(?, descricao)
       WHERE id = ?`,
      [nome ?? null, foto ?? null, umidade ?? null, luzSolar ?? null, temperatura ?? null, descricao ?? null, req.params.id]
    );
    const [rows] = await pool.query(`SELECT *, ${STATUS_SQL} AS status FROM plantas WHERE id = ?`, [req.params.id]);
    if (!rows.length) return res.status(404).json({ erro: 'Planta não encontrada.' });
    res.json(formatarPlanta(rows[0]));
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

app.delete('/api/plantas/:id', async (req, res) => {
  try {
    await pool.query('DELETE FROM plantas WHERE id = ?', [req.params.id]);
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// Botão "Regar Agora"
app.post('/api/plantas/:id/regar', async (req, res) => {
  try {
    const id = req.params.id;
    await pool.query(
      `UPDATE plantas SET umidade = 1.00, ultima_rega = CURDATE(),
         proxima_rega = CURDATE() + INTERVAL 3 DAY WHERE id = ?`,
      [id]
    );
    const [rows] = await pool.query(`SELECT *, ${STATUS_SQL} AS status FROM plantas WHERE id = ?`, [id]);
    if (!rows.length) return res.status(404).json({ erro: 'Planta não encontrada.' });
    res.json(formatarPlanta(rows[0]));
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// ---------- SENSORES (tabela leitura_sensores) ----------
function formatarLeitura(l) {
  const n = (v) => (v === null || v === undefined ? null : Number(v));
  return { id: l.id, luzSolar: n(l.luz_solar), umidade: n(l.umidade), temperatura: n(l.temperatura) };
}

// última leitura (usada nas telas das plantas)
app.get('/api/sensores/ultima', async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM leitura_sensores ORDER BY id DESC LIMIT 1');
    if (!rows.length) return res.status(404).json({ erro: 'Nenhuma leitura registrada.' });
    res.json(formatarLeitura(rows[0]));
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// histórico (?limite=20)
app.get('/api/sensores', async (req, res) => {
  try {
    const limite = Math.min(Number(req.query.limite) || 20, 200);
    const [rows] = await pool.query('SELECT * FROM leitura_sensores ORDER BY id DESC LIMIT ?', [limite]);
    res.json(rows.map(formatarLeitura));
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// registrar nova leitura (um sensor/ESP pode chamar esta rota)
app.post('/api/sensores', async (req, res) => {
  try {
    const { luzSolar, umidade, temperatura } = req.body;
    const [r] = await pool.query(
      'INSERT INTO leitura_sensores (luz_solar, umidade, temperatura) VALUES (?,?,?)',
      [luzSolar ?? null, umidade ?? null, temperatura ?? null]
    );
    res.status(201).json({ id: r.insertId });
  } catch (e) {
    console.error(e);
    res.status(500).json({ erro: 'Erro no servidor.' });
  }
});

// testa a conexão com o MySQL ao iniciar
pool.query('SELECT 1')
  .then(() => console.log('✅ Conectado ao MySQL em ' + process.env.DB_HOST))
  .catch((e) => console.error('❌ Falha ao conectar no MySQL:', e.code, e.message));

const PORT = process.env.PORT || 3333;
const server = app.listen(PORT, '0.0.0.0', () =>
  console.log(`API rodando na porta ${PORT}`)
);
server.on('error', (e) => {
  if (e.code === 'EADDRINUSE') {
    console.error(`❌ A porta ${PORT} já está em uso (a API já está aberta em outra janela?).`);
    console.error('   Feche a outra janela da API ou rode o INICIAR_API.bat, que libera a porta sozinho.');
  } else {
    console.error(e);
  }
  process.exit(1);
});
