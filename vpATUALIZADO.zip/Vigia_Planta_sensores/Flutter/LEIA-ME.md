# Vigia Planta - Flutter + MySQL

COMO USAR (2 cliques):
1. Clique duas vezes em INICIAR_API.bat   -> deve aparecer "API rodando na porta 3333" e "Conectado ao MySQL". Deixe a janela aberta.
2. Clique duas vezes em INICIAR_APP.bat   -> abre o app no Chrome.

Pastas:
- api/   API Node.js (liga o app ao MySQL). A configuracao esta em api/.env
- app/   projeto Flutter
- banco/ scripts SQL (ja executados; so rode de novo para recriar as tabelas)

IMPORTANTE:
- api/.env contem a senha do MySQL. APAGUE esse arquivo antes de enviar o projeto para outras pessoas.
- A API usa a porta 3333. Se mudar, mude tambem em app/lib/api_service.dart.
- Celular real: em app/lib/api_service.dart preencha urlManual com http://IP_DO_PC:3333/api

NOVO:
- Tabela leitura_sensores (luz_solar, umidade, temperatura) no banco/01_schema.sql e banco/03_leitura_sensores.sql.
- A tela da planta mostra a ultima leitura dos sensores; o painel inicial usa a luz solar da ultima leitura.
- Para registrar leituras de teste: INSERT INTO leitura_sensores (luz_solar, umidade, temperatura) VALUES (82.5, 47, 26.4);
- Botoes "Regar planta" e "Excluir planta" ficam fixos no rodape da tela da planta e tambem em cada card de Minhas Plantas.
