import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ApiService {
  // Para usar um celular real, troque por: 'http://IP_DO_SEU_PC:3333/api'
  // (ex: 'http://192.168.0.10:3333/api'). Deixe null para detecção automática.
  static const String? urlManual = null;

  static String get baseUrl {
    if (urlManual != null) return urlManual!;
    if (kIsWeb) return 'http://localhost:3333/api';
    // Emulador Android enxerga o PC em 10.0.2.2
    if (defaultTargetPlatform == TargetPlatform.android) {
      return 'http://10.0.2.2:3333/api';
    }
    return 'http://localhost:3333/api'; // Windows, iOS simulator, desktop
  }

  static const _headers = {'Content-Type': 'application/json'};

  /// Tempo máximo de espera pela API (evita ficar girando para sempre)
  static const _limite = Duration(seconds: 15);

  static Map<String, dynamic> _decode(http.Response r) =>
      jsonDecode(utf8.decode(r.bodyBytes)) as Map<String, dynamic>;

  /// JSON "1.00" chega como int no Dart; o app espera double.
  static Map<String, dynamic> _planta(Map<String, dynamic> p) {
    for (final k in ['waterLevel', 'sunLevel', 'temperatura']) {
      if (p[k] != null) p[k] = (p[k] as num).toDouble();
    }
    return p;
  }

  // ---------- AUTH ----------
  /// Retorna null se der certo, ou a mensagem de erro.
  static Future<String?> cadastrar({
    required String nome,
    required String email,
    required String senha,
    required String telefone,
    required bool aceitaLembretes,
  }) async {
    try {
      final r = await http.post(
        Uri.parse('$baseUrl/cadastro'),
        headers: _headers,
        body: jsonEncode({
          'nome': nome,
          'email': email,
          'senha': senha,
          'telefone': telefone,
          'aceitaLembretes': aceitaLembretes,
        }),
      ).timeout(_limite);
      if (r.statusCode == 201) return null;
      return _decode(r)['erro'] ?? 'Erro ao cadastrar (código ${r.statusCode}).';
    } catch (e) {
      debugPrint('Erro no cadastro: $e');
      return 'Sem conexão com a API em $baseUrl\nErro: $e';
    }
  }

  /// Retorna {id, nome, email} se der certo, ou {'erro': 'mensagem'} se falhar.
  static Future<Map<String, dynamic>> login(String email, String senha) async {
    try {
      final r = await http
          .post(
            Uri.parse('$baseUrl/login'),
            headers: _headers,
            body: jsonEncode({'email': email, 'senha': senha}),
          )
          .timeout(_limite);
      final dados = _decode(r);
      if (r.statusCode == 200) return dados;
      return {'erro': dados['erro'] ?? 'Erro ${r.statusCode}'};
    } on TimeoutException {
      return {
        'erro': 'A API demorou demais. Verifique se ela e o MySQL estão funcionando.'
      };
    } catch (e) {
      return {'erro': 'Sem conexão com a API em $baseUrl'};
    }
  }

  // ---------- BUSCA ----------
  static Future<List<Map<String, dynamic>>> buscarUsuarios(
      String termo, String tipo) async {
    try {
      final uri = Uri.parse('$baseUrl/usuarios/busca')
          .replace(queryParameters: {'termo': termo, 'tipo': tipo});
      final r = await http.get(uri);
      if (r.statusCode != 200) return [];
      return List<Map<String, dynamic>>.from(
          jsonDecode(utf8.decode(r.bodyBytes)));
    } catch (_) {
      return [];
    }
  }

  // ---------- PLANTAS ----------
  static Future<List<Map<String, dynamic>>> listarPlantas(int usuarioId) async {
    try {
      final r = await http
          .get(Uri.parse('$baseUrl/usuarios/$usuarioId/plantas'))
          .timeout(_limite);
      if (r.statusCode != 200) return [];
      return List<Map<String, dynamic>>.from(
              jsonDecode(utf8.decode(r.bodyBytes)))
          .map(_planta)
          .toList();
    } catch (_) {
      return [];
    }
  }

  static Future<Map<String, dynamic>?> adicionarPlanta({
    required int usuarioId,
    required String nome,
    String? foto,
    double umidade = 0.5,
    double luzSolar = 0.5,
    double? temperatura,
    String? descricao,
  }) async {
    try {
      final r = await http.post(
        Uri.parse('$baseUrl/plantas'),
        headers: _headers,
        body: jsonEncode({
          'usuarioId': usuarioId,
          'nome': nome,
          'foto': foto,
          'umidade': umidade,
          'luzSolar': luzSolar,
          'temperatura': temperatura,
          'descricao': descricao,
        }),
      );
      return r.statusCode == 201 ? _planta(_decode(r)) : null;
    } catch (_) {
      return null;
    }
  }

  /// Última leitura dos sensores: {luzSolar, umidade, temperatura} ou null.
  static Future<Map<String, dynamic>?> ultimaLeitura() async {
    try {
      final r = await http
          .get(Uri.parse('$baseUrl/sensores/ultima'))
          .timeout(_limite);
      if (r.statusCode != 200) return null;
      final l = _decode(r);
      for (final k in ['luzSolar', 'umidade', 'temperatura']) {
        if (l[k] != null) l[k] = (l[k] as num).toDouble();
      }
      return l;
    } catch (_) {
      return null;
    }
  }

  static Future<Map<String, dynamic>?> regarPlanta(int plantaId) async {
    try {
      final r = await http
          .post(Uri.parse('$baseUrl/plantas/$plantaId/regar'))
          .timeout(_limite);
      return r.statusCode == 200 ? _planta(_decode(r)) : null;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> excluirPlanta(int plantaId) async {
    try {
      final r = await http
          .delete(Uri.parse('$baseUrl/plantas/$plantaId'))
          .timeout(_limite);
      return r.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}

/// Usa asset local (assets/...) ou imagem da internet (http...) automaticamente.
ImageProvider imagemPlanta(String caminho) {
  if (caminho.startsWith('http')) return NetworkImage(caminho);
  return AssetImage(caminho);
}
